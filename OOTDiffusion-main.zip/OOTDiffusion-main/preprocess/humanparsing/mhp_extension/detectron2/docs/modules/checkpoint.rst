detectron2.checkpoint package
=============================

.. automodule:: detectron2.checkpoint
    :members:
    :undoc-members:
    :show-inheritance:
